### Utility Logic Explaination

For my utility function, I used the number of three contiguous tiles for my player minus those of the opponent. The reason I chose this utility function is because the state with more three contiguous tiles for my player would possibly lead to better opportunities for the agent to win opening up more possible spaces to attack.