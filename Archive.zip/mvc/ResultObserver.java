package c4.mvc;

public interface ResultObserver {
	void reportResult(int result);
}
