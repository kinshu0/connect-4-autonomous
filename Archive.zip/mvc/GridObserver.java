package c4.mvc;

public interface GridObserver {
	void updateGrid();
}
